<?php

?>

<!-- Entry Button Section -->
<section id="categories" class="py-5">
            <div class="container-fluid">
                <h2 class="text-center section-title mb-4"> আজকের বাজার দর - </h2>
                <div class="row justify-content-center">
                    <div class="col-2 col-responsive" >
                        <div class="feature-card">
                            <img src="assets/images/cart/rice.png" alt="Feature 1" class="card-img card-height">
                            <h4 class="mt-2">  ধান </h4>
                        </div>
                    </div>
                    <div class="col-2 col-responsive">
                        <div class="feature-card">
                            <img src="assets/images/cart/vurta.png" alt="Feature 2" class="card-img  card-height">
                            <h4 class="mt-2">ভূট্টা </h4>
                        </div>
                    </div>
                    <div class="col-2 col-responsive">
                        <div class="feature-card">
                            <img src="assets/images/cart/peyaj.png" alt="Feature 3" class="card-img  card-height">
                            <h4 class="mt-2">পেঁয়াজ  </h4>
                        </div>
                    </div>
                    <div class="col-2 col-responsive">
                        <div class="feature-card">
                            <img src="assets/images/cart/rosun.png" alt="Feature 4" class="card-img  card-height">
                            <h4 class="mt-2">রসুন </h4>
                        </div>
                    </div>
                    <div class="col-2 col-responsive">
                        <div class="feature-card">
                            <img src="assets/images/cart/alu.png" alt="Feature 5" class="card-img  card-height">
                            <h4 class="mt-2">আলু </h4>
                        </div>
                    </div>
                    <div class="col-2 col-responsive">
                        <div class="feature-card">
                            <img src="assets/images/cart/ada.png" alt="Feature 5" class="card-img  card-height">
                            <h4 class="mt-2">আদা </h4>
                        </div>
                    </div>
                </div>
            </div>
        </section>